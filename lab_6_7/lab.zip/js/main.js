$(window).on('load', function(){
 $('#header').vide('./video.video',{
    bgColor: '#64947b'
 });

});